#!/bin/sh

echo "Connecting PLC...."
cd epicsIOC_musr_modbus/
make
cd iocBoot/iocTest
SCREEN -d -m ../../bin/linux-x86_64/modbusApp binary.cmd
echo "PLC connected"

echo "Connecting other IOC...."
cd epicsIOC_musr_20220824ver/
make
cd iocBoot/iocTest
SCREEN -d -m ../../bin/linux-x86_64/serialTest st.cmd
echo "IOC connected"

